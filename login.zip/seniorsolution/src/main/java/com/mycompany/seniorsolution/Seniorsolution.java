/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.seniorsolution;

import java.util.Scanner;

/**
 *
 * @author Mateus
 */
public class Seniorsolution {
    static int[] armazena = new int[10];
    static int cont=0;
    
    public static int[] aumenta(int[] re){
        int[] narray = new int[re.length+10];
        for(int i=0;i<re.length;i++){
            narray[i]=re[i];
        }
        return narray;
    } 
    
    public static void verifica(int id){
        int c=0;
        int num;
        if(cont==armazena.length){
            armazena=aumenta(armazena);
        }
        for(int i=0;i<armazena.length;i++){
            if(id== armazena[i]){
                c++;
            }
        }
        if(c>0){
            System.out.println("esse numero ja existe\n");
            while(true){
                c=0;
                System.out.println("Introduza um numero que nao exista\n");
                //scanner
                Scanner my = new Scanner(System.in);
                num=my.nextInt();
                for(int i=0;i<armazena.length;i++){
                   if(num== armazena[i]){
                       c++;
            }
        }
                if(c==0){
                    armazena[cont]= num;
                    cont++;
                    break;
                }else{
                    continue;
                }
                
            }
        }else{
            armazena[cont]=id;
            cont++;
            c=0;
            System.out.println("valido");
        }
    }

    public static void main(String[] args) {
        System.out.println("Hello World!");
        int nume=0;
        Scanner mo = new Scanner(System.in);
        for(int i=0;i<5;i++){
            System.out.println("Introduza numero\n");
            nume=mo.nextInt();
            verifica(nume);
             
        }
        
    }
}
